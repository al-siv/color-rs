# Color Name to RGB Value Mapping Dataset
## Introduction
This dataset provides a comprehensive mapping between color names and their corresponding color values in hexadecimal RGB format.
It specifies the color family each color originates from, such as RAL or Pantone.
## Sources
1. https://web.archive.org/web/20070125105444/http://www-swiss.ai.mit.edu/~jaffer/Color/Dictionaries.html
2. https://github.com/Margaret2/pantone-colors